/* Shared front-end: maps, seat-distribution charts, sortable table, ladder. */
(function () {
  const tip = document.getElementById('tip');
  function showTip(html, ev) {
    if (!tip) return;
    tip.innerHTML = html; tip.style.display = 'block';
    const x = (ev.clientX || 0) + 14, y = (ev.clientY || 0) + 14;
    tip.style.left = Math.min(x, window.innerWidth - 280) + 'px';
    tip.style.top = Math.min(y, window.innerHeight - 90) + 'px';
  }
  function hideTip() { if (tip) tip.style.display = 'none'; }
  window.showTip = showTip; window.hideTip = hideTip;

  // probability -> colour (diverging, 7 steps + continuous interpolation)
  const colour = d3.scaleLinear().domain([0, 0.2, 0.35, 0.5, 0.65, 0.8, 1])
    .range(['#b1261a', '#d9402b', '#f0a99c', '#d8d0e8', '#9cc0f0', '#2a6fdb', '#1b4ea3']).clamp(true);
  window.probColour = colour;
  const fmtM = m => (m == null || isNaN(m)) ? '—' : (m > 0 ? 'D+' : 'R+') + Math.abs(m).toFixed(1);
  const pct = p => (p == null || isNaN(p)) ? '—' : Math.round(p * 100) + '%';
  window.fmtM = fmtM; window.pct = pct;

  // ---------- seat distribution charts ----------
  window.drawSeatDistributions = function (F) {
    document.querySelectorAll('svg.dist').forEach(svg => {
      const ch = svg.dataset.chamber, c = F.chambers[ch];
      const W = svg.clientWidth || 480, H = 160, m = { l: 8, r: 8, t: 10, b: 24 };
      const dist = Object.entries(c.distribution).map(([k, v]) => ({ k: +k, v: v / F.n_sims }));
      const ks = dist.map(d => d.k);
      const lo = Math.max(0, d3.min(ks) - 1), hi = Math.min(c.total_seats, d3.max(ks) + 1);
      const x = d3.scaleBand().domain(d3.range(lo, hi + 1)).range([m.l, W - m.r]).padding(0.1);
      const y = d3.scaleLinear().domain([0, d3.max(dist, d => d.v)]).range([H - m.b, m.t]);
      const s = d3.select(svg).attr('viewBox', `0 0 ${W} ${H}`);
      s.selectAll('*').remove();
      s.selectAll('rect').data(dist).join('rect')
        .attr('x', d => x(d.k)).attr('width', x.bandwidth())
        .attr('y', d => y(d.v)).attr('height', d => y(0) - y(d.v))
        .attr('fill', d => d.k >= c.majority ? 'var(--dem)' : 'var(--rep)')
        .on('mousemove', (ev, d) => showTip(`<b>${d.k} Democratic seats</b><br>${(d.v * 100).toFixed(1)}% of simulations`, ev))
        .on('mouseleave', hideTip);
      // majority line
      const mx = x(c.majority) != null ? x(c.majority) - x.step() * 0.05 : null;
      if (mx != null) {
        s.append('line').attr('x1', mx).attr('x2', mx).attr('y1', m.t).attr('y2', H - m.b).attr('stroke', 'var(--fg)').attr('stroke-dasharray', '3,3');
        s.append('text').attr('x', mx + 4).attr('y', m.t + 10).attr('font-size', 11).text(`majority (${c.majority})`);
      }
      const ticks = d3.range(lo, hi + 1).filter(k => k % (hi - lo > 40 ? 10 : 5) === 0);
      s.append('g').attr('class', 'axis').attr('transform', `translate(0,${H - m.b})`)
        .call(d3.axisBottom(x).tickValues(ticks).tickSize(3)).selectAll('text').attr('font-size', 11);
      s.append('text').attr('x', W / 2).attr('y', H - 2).attr('text-anchor', 'middle').attr('font-size', 11).attr('fill', 'var(--muted)').text('Democratic seats after the election');
    });
  };

  // ---------- map ----------
  window.initMap = function (id, F, rel) {
    const svg = d3.select('#' + id); if (svg.empty()) return;
    const bySeat = {}; F.seats.forEach(s => bySeat[s.seat] = s);
    const up = new Set(F.seats.map(s => s.seat));
    let current = 'house';
    const geo = {};
    const projection = d3.geoMercator();
    const path = d3.geoPath(projection);
    function draw(ch) {
      current = ch;
      const g = geo[ch]; if (!g) return;
      projection.fitSize([900, 560], g);
      const prefix = ch === 'house' ? 'H' : 'S';
      svg.selectAll('path.county').remove();
      const sel = svg.selectAll('path.d').data(g.features, d => d.properties.district);
      sel.join('path').attr('class', 'd').attr('d', path)
        .attr('fill', d => { const s = bySeat[prefix + d.properties.district]; return s ? colour(s.p_dem) : '#bbb'; })
        .on('mousemove', (ev, d) => {
          const s = bySeat[prefix + d.properties.district];
          const label = (ch === 'house' ? 'House District ' : 'Senate District ') + d.properties.district;
          if (!s) return showTip(`<b>${label}</b><br>Not up in 2026`, ev);
          showTip(`<b>${label}</b><br>${s.dem_cand || '—'} (D) v. ${s.rep_cand || '—'} (R)<br>P(Dem) ${pct(s.p_dem)} · ${fmtM(s.margin_mean)}${s.uncontested ? '<br><i>uncontested</i>' : ''}`, ev);
        })
        .on('mouseleave', hideTip)
        .on('click', (ev, d) => { const s = bySeat[prefix + d.properties.district]; if (s) location.href = rel + 'districts/' + s.seat + '.html'; });
      if (geo.counties) {
        svg.selectAll('path.county').data(geo.counties.features).join('path').attr('class', 'county').attr('d', path)
          .attr('fill', 'none').attr('stroke', 'var(--fg)').attr('stroke-opacity', 0.25).attr('stroke-width', 0.6).attr('pointer-events', 'none');
      }
    }
    Promise.all([
      d3.json(rel + 'assets/geo/house.geojson'), d3.json(rel + 'assets/geo/senate.geojson'),
      d3.json(rel + 'assets/geo/counties.geojson').catch(() => null)
    ]).then(([h, s, c]) => { geo.house = h; geo.senate = s; geo.counties = c; draw('house'); });
    document.querySelectorAll('button.tab[data-map]').forEach(b => b.addEventListener('click', () => {
      document.querySelectorAll('button.tab[data-map]').forEach(x => x.classList.remove('active'));
      b.classList.add('active'); draw(b.dataset.map);
    }));
  };

  // ---------- seats table ----------
  window.initSeatsTable = function (F) {
    const tbody = document.querySelector('#seats tbody');
    const q = document.getElementById('q'), chS = document.getElementById('chamber'), rS = document.getElementById('rating'), cOnly = document.getElementById('contested');
    let sortK = 'p_flip', asc = false;
    const regionLabel = r => ({ philadelphia: 'Philadelphia', collar: 'Collar counties', lehigh_valley: 'Lehigh Valley', pittsburgh_metro: 'Pittsburgh metro', central: 'Central', northeast: 'Northeast', northwest: 'Northwest' })[r] || r;
    function render() {
      let rows = F.seats.slice();
      const qq = (q.value || '').toLowerCase();
      if (qq) rows = rows.filter(s => [s.label, s.dem_cand, s.rep_cand, s.incumbent_name, regionLabel(s.region), s.rating].join(' ').toLowerCase().includes(qq));
      if (chS.value) rows = rows.filter(s => s.chamber === chS.value);
      if (rS.value) rows = rows.filter(s => s.rating === rS.value);
      if (cOnly.checked) rows = rows.filter(s => !s.uncontested);
      rows.sort((a, b) => {
        let va = a[sortK], vb = b[sortK];
        if (sortK === 'seat') { va = (a.chamber === 'house' ? 0 : 1000) + a.district; vb = (b.chamber === 'house' ? 0 : 1000) + b.district; }
        if (va == null) return 1; if (vb == null) return -1;
        if (typeof va === 'string') return asc ? va.localeCompare(vb) : vb.localeCompare(va);
        return asc ? va - vb : vb - va;
      });
      tbody.innerHTML = rows.map(s => `<tr>
        <td><a href="districts/${s.seat}.html">${s.label}</a>${s.uncontested ? ' <span class="note">(unc.)</span>' : ''}${s.open_seat ? ' <span class="note">(open)</span>' : ''}</td>
        <td>${regionLabel(s.region)}</td>
        <td><span class="pill" style="background:var(--${s.holder_party === 'D' ? 'dem' : s.holder_party === 'R' ? 'rep' : 'tie'})">${s.holder_party}</span></td>
        <td>${s.dem_cand || '—'}</td><td>${s.rep_cand || '—'}</td>
        <td class="num">${fmtM(s.lean)}</td><td class="num">${fmtM(s.mu_fundamentals)}</td><td class="num">${fmtM(s.margin_mean)}</td>
        <td class="num" style="color:${colour(s.p_dem)};font-weight:600">${pct(s.p_dem)}</td><td class="num">${pct(s.p_flip)}</td>
        <td>${s.rating}</td><td class="num">${s.tipping ? (s.tipping * 100).toFixed(1) + '%' : '—'}</td></tr>`).join('');
      document.querySelectorAll('#seats th').forEach(th => { th.classList.toggle('sorted', th.dataset.k === sortK); th.classList.toggle('asc', th.dataset.k === sortK && asc); });
    }
    document.querySelectorAll('#seats th').forEach(th => th.addEventListener('click', () => {
      if (sortK === th.dataset.k) asc = !asc; else { sortK = th.dataset.k; asc = (sortK === 'seat' || sortK === 'dem_cand' || sortK === 'rep_cand' || sortK === 'region'); }
      render();
    }));
    [q, chS, rS, cOnly].forEach(el => el.addEventListener('input', render));
    render();
  };

  // ---------- ladder (seats ordered by margin) ----------
  window.drawLadder = function (id, F) {
    const svg = d3.select('#' + id); if (svg.empty()) return;
    const W = svg.node().clientWidth || 900, H = 320;
    svg.attr('viewBox', `0 0 ${W} ${H}`);
    const chambers = ['house', 'senate'];
    chambers.forEach((ch, i) => {
      const c = F.chambers[ch];
      const seats = F.seats.filter(s => s.chamber === ch).sort((a, b) => b.margin_mean - a.margin_mean);
      const y0 = i * (H / 2) + 24, h = H / 2 - 50;
      const x = d3.scaleBand().domain(seats.map(s => s.seat)).range([10, W - 10]).padding(0.05);
      const maxAbs = Math.min(60, d3.max(seats, s => Math.abs(s.margin_mean)) || 30);
      const y = d3.scaleLinear().domain([-maxAbs, maxAbs]).range([y0 + h, y0]);
      const g = svg.append('g');
      g.append('text').attr('x', 10).attr('y', y0 - 8).attr('font-size', 13).attr('font-weight', 600).text(ch === 'house' ? 'State House (203 seats)' : 'State Senate (25 seats up)');
      g.selectAll('rect').data(seats).join('rect')
        .attr('x', s => x(s.seat)).attr('width', Math.max(1, x.bandwidth()))
        .attr('y', s => Math.min(y(0), y(Math.max(-maxAbs, Math.min(maxAbs, s.margin_mean)))))
        .attr('height', s => Math.abs(y(0) - y(Math.max(-maxAbs, Math.min(maxAbs, s.margin_mean)))))
        .attr('fill', s => colour(s.p_dem))
        .on('mousemove', (ev, s) => showTip(`<b>${s.label}</b><br>${fmtM(s.margin_mean)} · P(Dem) ${pct(s.p_dem)}${s.tipping ? `<br>tipping-point ${(s.tipping * 100).toFixed(1)}%` : ''}`, ev))
        .on('mouseleave', hideTip)
        .on('click', (ev, s) => location.href = 'districts/' + s.seat + '.html');
      g.append('line').attr('x1', 10).attr('x2', W - 10).attr('y1', y(0)).attr('y2', y(0)).attr('stroke', 'var(--fg)').attr('stroke-opacity', 0.5);
      // majority line: Dems need `need` seats among these
      const need = c.majority - (c.holdover_dem || 0);
      if (need > 0 && need <= seats.length) {
        const mx = x(seats[need - 1].seat) + x.bandwidth();
        g.append('line').attr('x1', mx).attr('x2', mx).attr('y1', y0).attr('y2', y0 + h).attr('stroke', 'var(--fg)').attr('stroke-dasharray', '4,3');
        g.append('text').attr('x', mx + 4).attr('y', y0 + 12).attr('font-size', 11).text(`Dem majority needs ${need} → ${seats[need - 1].label}`);
      }
      const rNeed = (c.majority - (c.holdover_rep || 0));
      if (rNeed > 0 && rNeed <= seats.length) {
        const idx = seats.length - rNeed; const mx = x(seats[idx].seat);
        g.append('line').attr('x1', mx).attr('x2', mx).attr('y1', y0).attr('y2', y0 + h).attr('stroke', 'var(--fg)').attr('stroke-dasharray', '1,3');
      }
    });
  };

  window.drawEnvDist = function (id, D) {
    const svg = d3.select('#' + id); if (svg.empty()) return;
    const W = svg.node().clientWidth || 800, H = 140, m = { l: 8, r: 8, t: 8, b: 22 };
    svg.attr('viewBox', `0 0 ${W} ${H}`);
    const bins = D.hist_bins.slice(0, -1).map((b, i) => ({ lo: b, hi: D.hist_bins[i + 1], v: D.hist[i] }));
    const total = d3.sum(bins, b => b.v);
    const x = d3.scaleLinear().domain([-20, 20]).range([m.l, W - m.r]);
    const y = d3.scaleLinear().domain([0, d3.max(bins, b => b.v)]).range([H - m.b, m.t]);
    svg.selectAll('rect').data(bins).join('rect').attr('x', b => x(b.lo) + 1).attr('width', x(1) - x(0) - 2)
      .attr('y', b => y(b.v)).attr('height', b => y(0) - y(b.v)).attr('fill', b => (b.lo + b.hi) / 2 > 0 ? 'var(--dem)' : 'var(--rep)')
      .on('mousemove', (ev, b) => showTip(`${fmtM(b.lo)} to ${fmtM(b.hi)}: ${(100 * b.v / total).toFixed(1)}%`, ev)).on('mouseleave', hideTip);
    svg.append('g').attr('class', 'axis').attr('transform', `translate(0,${H - m.b})`).call(d3.axisBottom(x).ticks(9).tickFormat(v => v === 0 ? 'even' : (v > 0 ? 'D+' : 'R+') + Math.abs(v)));
  };
})();
